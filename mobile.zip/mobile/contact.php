<?php
error_reporting(0);
class sendMail {
	public function sendemail($to, $subject, $message, $fromaddress,$fromname='', $xheaders = '') {
			$eol="\n";
			$fromname=$fromname?$fromname:$fromaddress;
			$to=preg_replace("/(\r\n|\r|\n)/s",'', trim($to));
			$subject=preg_replace("/(\r\n|\r|\n)/s",'', trim($subject));
			$message = preg_replace("/(\r\n|\r)/s", "\n", trim($message));
			$headers .= "From: ".$fromname."<".$fromaddress.">".$eol;
			$headers .= "Reply-To: ".$fromname."<".$fromaddress.">".$eol;
			$headers .= "Return-Path: ".$fromname."<".$fromaddress.">".$eol;
			$headers .= "Message-ID: <".time()."-".$fromaddress.">".$eol;
			$headers .= "X-Mailer: All Action  ".$eol;
			if($xheaders) { 
				$headers .= $xheaders;
			 }else{
				$headers .= "Content-Type: text/html; charset=utf-8".$eol;
				$headers .= "Content-Transfer-Encoding: 8bit".$eol;
			 }			 
			 if(mail($to,$subject,$message,trim($headers)))
			 return true;
		}
	}
$objMail = new sendMail;
if(isset($_POST['quicksubmit'])){
$to      = "newcastlepatios@bigpond.com";
$subject = "Message Sent via Website";
$message = "Contact Details:<br>
			================================<br />			
			<p>Full Name: '".$_POST['name']."' </p>	
			<p>Phone Number: '".$_POST['tel']."' </p>			
			<p>Email Address: '".$_POST['email']."'</p>
			<p>Address: '".$_POST['address']."'</p>
			<p>Question: '".$_POST['question']."'</p>
			Thank You";			
$from 		= 	trim($_POST['email']);
$fromName	=	trim($_POST['name']);
$mailFormat	=	"text/html";
		
if($objMail->sendemail($to, $subject, $message, $from, $fromName, $mailFormat = '')){
	$success = "Your email has been successfully sent.";	
	$flag = 1;
	
	}else{
		$err = "Please try again";
	$flag = 0;
	}
}	
?>
<!DOCTYPE html>
<html>
	<head>
		
		<meta name="author" content="www.frebsite.nl" />
		<meta name="viewport" content="width=device-width initial-scale=1.0 maximum-scale=1.0 user-scalable=yes" />

		<title>Newcastle Patio - Contact</title>
		<link href="img/favicon.ico" rel="shortcut icon" type="image/x-icon" />

		<link type="text/css" rel="stylesheet" href="css/jquery.mmenu.all.css" />
		<link type="text/css" rel="stylesheet" href="css/style.css" />
             <link type="text/css" rel="stylesheet" href="css/font-awesome.css" />

		<link rel="apple-touch-icon" href="img/apple-touch-icon.png" />
		<link rel="apple-touch-startup-image" href="img/apple-touch-startup-image.png" />
		
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/jquery.mmenu.min.all.js"></script>
		<script type="text/javascript" src="js/o-script.js"></script>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>
	<body class="o-page p-contact">
		<div id="page">
			<div id="header">
				<div class="header-content">
					<a href="index.html" class="p-link-home"><i class="fa fa-home"></i></a>
					<a class="menu-btn" href="#menu"></a>
					<a href="javascript:history.back();" class="p-link-back"><i class="fa fa-arrow-left"></i></a>
				</div>
			</div>
			<div class="bannerPane" style="height:300px">
				<div class="map"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?q=Robert+St,+Wallsend,+NSW,+2287&oe=utf-8&client=firefox-aurora&ie=UTF8&hq=&hnear=Robert+St,+Wallsend+New+South+Wales+2287,+Australia&t=m&z=14&ll=-32.899809,151.673322&output=embed"></iframe><br /><small><a href="https://maps.google.com/maps?q=Wallsend,+NSW,+2287&oe=utf-8&client=firefox-aurora&ie=UTF8&hq=&hnear=Robert+St,+Wallsend+New+South+Wales+2287,+Australia&t=m&z=14&ll=-32.899809,151.673322&source=embed" style="color:#0000FF;text-align:left">View Larger Map</a></small>  
                
                 </div>
				<div class="s-banner-content">
					<div><img width="100" src="img/logo-pages.png" /></div>
				</div>
                </div>
			</div>
			<!-- MAP -->
			
			<div id="content">
				
				<h3 class="title"><i class="fa fa-envelope"></i> Contact us</h3>
				
				<p class="try-again">
            <?php if($flag == 1){
				  echo $success;
				  }else if($flag == 0){
					  echo $err;
					  }?>
          </p>
          <form action="" method="post" class="contactForm"  name="frm" id="frm" style="margin-top:0" onsubmit="return validate()">
					<tr>
					<label>Full Name <span class="required">*</span></label>
					<input type="text" required name="name" id="name" placeholder="Name" />
					</tr>
                    
                       <tr>
					<label>Phone <span class="required">*</span></label>
					<input type="text" required name="tel" id="tel" placeholder="Phone Number" />
                    </tr>
                    	<tr>
					<label>Email <span class="required">*</span></label>
					<input type="email"  required name="email" id="email" placeholder="Email" />
                    </tr>
						<tr>
                        
                                          <tr>
					<label>Address <span class="required">*</span></label>
					<input type="text" required name="address" id="address" placeholder="Address" />
                    </tr>

                    
                   
						<tr>
					<label>Your question(s) <span class="required">*</span></label>
					<textarea id="question" required name="question" placeholder="Question here..."></textarea>
                    </tr>
						<tr>
					<button type="submit" name="quicksubmit" class="submit">SUBMIT</button><button type="reset"  class="submit">Reset</button>
					</tr>
				
				</form>

				<h3 class="title">Contact Details</h3>
				<p class="padding">
					Wallsend NSW 2287, Australia<br />
					<i class="fa fa-map-marker" style="display:none"></i>Builders Lic NO: 79817C <br />
				
				</p>
                <p><i class="fa fa-phone-square"></i>Phone: (024) 9513 852</p>
                <p><i class="fa fa-mobile" style="font-size:18px; padding:0 6px"></i>Mobile: (041) 1407 753</p>
                <p><i class="fa fa-file-text-o" style="padding:0 6px; font-size:12px"></i>Fax: (041) 1407 753</p>
                <p><i class="fa fa-envelope-o" style="font-size:11px;padding:0 5px"></i>Email:newcastlepatios@bigpond.com</p>
			</div>
			
			<div class="subFooter">
            <div class="a-scl-icons">
								<a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a>
								<a href="https://www.twitter.com/" target="_blank"><i class="fa fa-twitter"></i></a>
								<a href="https://www.plus.google.com/" target="_blank"><i class="fa fa-google-plus"></i></a>
							</div>
            
            Copyright 2014. All rights reserved.</div>
			
			<!-- Menu navigation -->
			<nav id="menu">
				<ul>
					<li class="Selected">
						<a href="index.html">
							<i class="fa fa-home"></i>Home
						</a>
					</li>
					<li>
						<a href="about.html">
							<i class="fa fa-users"></i>About
						</a>
					</li>
                    <li>
						<a href="service.html">
							<i class="fa fa-cogs"></i> Our Services
						</a>
					</li>
					
					<li>
						<a href="gallery.html">
							<i class="fa fa-picture-o"></i>Gallery
						</a>
					
					</li>
					<li>
						<a href="testimonials.php">
							<i class="fa fa-th-list"></i>Testimonials
						</a>
					
					</li>
					<li>
						<a href="quote.php">
							<i class="fa fa-list-alt"></i>Quote
						</a>
					</li>
					<li>
						<a href="contact.php">
							<i class="fa fa-envelope"></i>Contact
						</a>
					</li>
				</ul>
			</nav>
			
		</div>
        
        
	</body>
</html>