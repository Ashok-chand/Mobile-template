<?php
session_start();
?>
<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="Epsilon, mobile, framework, css3, html5, javascript, retina" />
<meta name="Description" content="Epsilon based mobile retina webpp template!" />
<!--Favicon shortcut link-->
<link type="image/x-icon" rel="shortcut icon" href="images/favicon.ico" />
<link type="image/x-icon" rel="icon" href="images/splash/favicon.ico" />
<!--Declare page as mobile friendly --> 
<meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0" />
<!-- Declare page as iDevice WebApp friendly -->
<meta name="apple-mobile-web-app-capable" content="yes" />
<!-- iDevice WebApp Splash Screen, Regular Icon, iPhone, iPad, iPod Retina Icons -->
<link rel="apple-touch-icon" sizes="114x114" href="images/splash/splash-icon.png" /> 
<link rel="apple-touch-startup-image" href="images/splash/splash-screen.png" media="screen and (max-device-width: 320px)" /> 
<link rel="apple-touch-startup-image" href="images/splash/splash-screen@2x.png" media="(max-device-width: 480px) and (-webkit-min-device-pixel-ratio: 2)" /> 
<link rel="apple-touch-startup-image" href="images/splash/splash-screen@3x.png" sizes="640x1096" />

<!-- Page Title -->
<title>Windmill Landscapes</title>

<!-- Stylesheet Load -->
<link href="styles/style.css" rel="stylesheet" type="text/css" />
<link href="styles/framework-style.css" rel="stylesheet" type="text/css" />
<link href="styles/framework.css" rel="stylesheet" type="text/css" />
<link href="styles/icons.css" rel="stylesheet" type="text/css" />
<link href="styles/coach.css" rel="stylesheet" type="text/css" />
<link href="styles/retina.css" rel="stylesheet" type="text/css" media="only screen and (-webkit-min-device-pixel-ratio: 2)" />
<!--for slider-->
<link rel="stylesheet" href="styles/slider/idangerous.swiper.css">
<link rel="stylesheet" href="styles/slider/swiper-style.css">
<!-- for footer nav icon -->
<link rel="stylesheet" href="styles/footer/jquery.mobile-1.2.0-beta.1.min.css" />

<!-- for date picker -->
<link rel="stylesheet" href="styles/jquery-ui.css" type="text/css" />
<link rel="stylesheet" href="styles/jquery-ui-timepicker-addon.css" type="text/css" />
<!-- end -->



<script language="javascript" type="text/javascript">
		var dateObject=new Date();
</script>
 

</head>

<body>
<div id="preloader">
	<div id="status">
    	<p class="center-text">
						Loading up the content!
            <em>Loading depends on connection speed</em>
        </p>
    </div>
</div>

<div id="modal-hider"></div>
<div id="modal-body">
   
  <div class="decoration"></div>
  <a href="#" class="close-modal">Close</a>
  <em class="close-modal-text">Addresses will remain confidential!</em>
</div>



<div class="content">

    <div class="container header white-box top-decoration">
		<a href="./"><img class="logo replace-2x" src="images/misc/logo.png" alt="img" /></a>
        
		
    </div>
    <div class="container">
    <div class="nav1">
    	<a  class="deploy-nav"><span>Menu</span></a>
        <div class="navigation">
    <ul>
    	<li><a href="index.html" class="nav-icon home-nav">Home</a></li>
        <li ><a href="gallery.html" id="menu-three1" class="nav-icon gallery-nav ho">Gallery</a></li>
        <li class="active-nav"><a href="contact.php" id="menu-four1" class="nav-icon mail-nav ho">Contact Us</a></li>
        </ul>
        
        <div class="clear"></div>
 </div>
        </div>
    </div>
    <div><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d50310.16878542872!2d145.06055425412077!3d-37.991466605955736!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad66da799b93551%3A0x5045675218cdfd0!2sMordialloc+VIC%2C+Australia!5e0!3m2!1sen!2snp!4v1409024444556" width="100%" height="250" frameborder="0" style="border:0"></iframe>
    </div>
    <div class="white-box container">
        <div class="container no-bottom">
         <h5 class="container-title uppercase">Contact Us</h5>
		 <div class="decoration"></div>
         
            <div class="modalForm" id="modalForm">
         <div class="popup" id="mess">
                    <?php  if(isset($_SESSION['success'])){ ?>
                    
                    <div class="sent"><h4>Message sent successfully.</h4></div>
                    <p style="color:#0A7D00;">Thank you for contacting us. We have received your queries. We will respond you as soon as possible.</p>
                    
                    <?php unset($_SESSION['success']);}
					elseif(isset($_SESSION['error']))  {?>
                    <div class="sent"><h4>Message failed.</h4></div>
                    <p style="color:#C74350;">Something went wrong. Please try again.</p>
                    <?php unset($_SESSION['error']);}
					elseif(isset($_SESSION['failed']))  {?>
                    <div class="sent"><h4>Message Error.</h4></div>
					<p style="color:#C74350;">You did not type the security code correctly. Our policy is to avoid messages from spammers.</p>
                    
                    
                    <?php unset($_SESSION['failed']);}
					
					?>
					
                   </div>
      <form method="post" action="message-send.php" id="contactform" >
                                   
                                   
                                   <fieldset>
                                        
                                        <div class="fieldBlock">
                                             <p>
                                              <label id="name_label">Name*</label>
                                           <input type="text" name="name" id="contactname" value="" class="text-input" role="input" aria-required="true" required="required" />
                                             </p>
                                             <p>
                                                  <label id="name_label">Email*</label>
                                                  <input type="email" name="email" id="email" value="" class="text-input" role="input" aria-required="true" required="required" />
                                             </p>
                                             
                                             <p>
                                                  <label id="name_label">Phone* </label>
                                                  <input type="text" name="phone" value="" id="phone"  class="text-input" />
                                                  
                                             </p>
                                             
                                             <p>
                                                  <label id="name_label">Subject </label>
                                                  <input type="text" name="subject" id="subject" value="" class="text-input" role="input" aria-required="true" />
                                                  
                                             </p>
                                             <p>
                                                  <label id="name_label">Message </label>
                                                  <textarea rows="8" name="message" id="message" class="text-input" role="textbox" aria-required="true" /></textarea>
                                                  
                                             </p>
                                             <p>
                                                <input class="button" type="submit" name="submit" value="Submit"/>
                                                </p>
                                        </div>
                                   </fieldset>
                                 </form>
      
      
  </div>
        </div>
    </div>

    
  
    <div class="container footer-wrap white-box bottom-decoration">
    	<p class="center-text footer-text">&copy; <script type="text/javascript">
document.write(dateObject.getFullYear()); 
</script> Windmill Landscapes. All Rights Reserved.</p>
<p class="center-text"><a href="http://www.crossoverweb.com.au/" class="powered" title="CrossOver Web"><img src="images/powered-by.png"></a></p>

      	<p class="center-text footer-sub-text">
        	<a class="go-up" href="#">Back to top</a>
       </p> 
         
       
    </div>
 <!-- If you want to use your mobile project copy / paste this (FOOTER) -->
  <div class="nav-glyphish ui-footer ui-bar-a ui-footer-fixed slideup" data-theme="a" data-position="fixed" data-role="footer" role="contentinfo">
<div class="nav-glyphish ui-navbar ui-mini" data-grid="c" data-role="navbar" role="navigation">
<ul class="ui-grid-c">
                              
<li class="ui-block-a">
<a href="./" class="iconsub-white-House  ui-btn ui-btn-inline ui-btn-icon-top ui-btn-up-a " data-icon="custom"  data-corners="false" data-shadow="false" data-iconshadow="true" data-wrapperels="span" data-iconpos="top" data-theme="a" data-inline="true">
                  <span class="ui-btn-inner">
                     <span class="ui-btn-text">Home</span>
                     <span id="iconsub-white-House" class="ui-icon"> </span>
                     </span></a>

  </li>
                              
                              
<li class="ui-block-b">
	<a class="iconsub-white-Phone ui-btn ui-btn-inline ui-btn-icon-top ui-btn-up-a" data-icon="custom" href="tel:0406567823" data-corners="false" data-shadow="false" data-iconshadow="true" data-wrapperels="span" data-iconpos="top" data-theme="a" data-inline="true">
                              <span class="ui-btn-inner">
                             <span class="ui-btn-text">Phone</span>
                             <span id="iconsub-white-Phone" class="ui-icon"> </span>
 </span></a>
</li>

<li class="ui-block-c">
	<a href="sms:0406567823" class="iconsub-white-Idcard ui-btn ui-btn-inline ui-btn-icon-top ui-btn-up-a" data-icon="custom"  data-corners="false" data-shadow="false" data-iconshadow="true" data-wrapperels="span" data-iconpos="top" data-theme="a" data-inline="true">
      <span class="ui-btn-inner">
     <span class="ui-btn-text">SMS</span>
     <span id="iconsub-white-Idcard" class="ui-icon"> </span>
     </span>
     </a>
</li>
                              
<li class="ui-block-d">
	<a href="mailto:navarrejanse@gmail.com" class="iconsub-white-Envelope ui-btn ui-btn-inline ui-btn-icon-top ui-btn-up-a" data-icon="custom" data-corners="false" data-shadow="false" data-iconshadow="true" data-wrapperels="span" data-iconpos="top" data-theme="a" data-inline="true">
       
     <span class="ui-btn-inner">
     <span class="ui-btn-text">Email</span>
     <span id="iconsub-white-Envelope" class="ui-icon"> </span>
     </span>
       </a>
 </li>
 </ul>
   </div>
 </div>
<!-- end -->
</div>
<!--Page Scripts Load -->
<script src="scripts/jquery.min.js" type="text/javascript"></script>		
<script src="scripts/jquery-ui-min.js" type="text/javascript"></script>
<script src="scripts/subscribe.js" type="text/javascript"></script>
<script src="scripts/contact.js" type="text/javascript"></script>
<script src="scripts/swipe.js" type="text/javascript"></script>
<script src="scripts/klass.min.js" type="text/javascript"></script>
<script src="scripts/photoswipe.js" type="text/javascript"></script>
<script src="scripts/colorbox.js" type="text/javascript"></script>
<script src="scripts/retina.js" type="text/javascript"></script>
<script src="scripts/custom.js" type="text/javascript"></script>
<script src="scripts/framework.js" type="text/javascript"></script>
<script src="scripts/jquery.min.js" type="text/javascript"></script>
<script>
    $(document).ready(function() {  
    var stickyNavTop = $('.nav1').offset().top;  
      
    var stickyNav = function(){  
    var scrollTop = $(window).scrollTop();  
           
    if (scrollTop > stickyNavTop) {   
        $('.nav1').addClass('sticky');  
    } else {  
        $('.nav1').removeClass('sticky');   
    }  
    };  
      
    stickyNav();  
      
    $(window).scroll(function() {  
        stickyNav();  
    });  
    });  
</script>

</body>
</html>
<?php
session_destroy();

?>